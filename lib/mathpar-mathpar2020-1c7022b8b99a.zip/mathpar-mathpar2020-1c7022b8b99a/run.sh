mvn -e -DskipTests=true clean package spring-boot:run     
