package com.mathpar.Graphic2D.paintElements.GeometryEngine.constants;

public enum OperatorKind {
    FUNCTION,
    BIN_INFIX
}
