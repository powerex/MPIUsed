/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.Graphic3D.ZBuffer;

public class Run {

    public static void main(String[] args) {
        Core core = new Core();
    }
}
