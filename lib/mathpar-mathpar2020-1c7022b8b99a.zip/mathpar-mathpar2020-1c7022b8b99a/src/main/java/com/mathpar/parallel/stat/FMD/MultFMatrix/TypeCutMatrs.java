/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.parallel.stat.FMD.MultFMatrix;

/**
 *
 * @author vladimir
 */
public enum TypeCutMatrs {
    CUT_ROW,
    CUT_COLS,
    CUT_BLOCKS

}
