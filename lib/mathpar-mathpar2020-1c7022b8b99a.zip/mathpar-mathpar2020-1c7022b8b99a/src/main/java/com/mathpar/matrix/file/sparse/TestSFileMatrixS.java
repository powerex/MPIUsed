/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.matrix.file.sparse;

import com.mathpar.matrix.file.utils.BaseMatrixDir;
import java.util.Random;


/**
 * @author not attributable
 * @version 1.0
 */
public class TestSFileMatrixS {
    public static void main(String[] args) throws Exception{
        Random rnd = new Random(12345);

        //очистить базовую директорию
        BaseMatrixDir.clearMatrixDir();
    }
}
