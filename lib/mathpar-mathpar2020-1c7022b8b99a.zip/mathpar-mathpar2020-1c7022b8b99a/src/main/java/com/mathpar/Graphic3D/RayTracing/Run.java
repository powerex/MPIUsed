/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.Graphic3D.RayTracing;

public class Run {

    public static void main(String[] args) {
        // Запускаем ядро.
        new Core();
    }
}
