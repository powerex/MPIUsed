/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.parallel.stat.FMD.MultFMatrix;

/**
 * Created with IntelliJ IDEA.
 * User: vladimir
 * Date: 17.02.14
 * Time: 21:58
 * To change this template use File | Settings | File Templates.
 */
public  interface TagSending {
    public static final int TAG_SEND_ARRAY_LEN = 123;
    public static final int TAG_SEND_ARRAY_FM = 300;
    public static final int TAG_SEND_FINAl_IN_PROC_0 = 300;
    public static final int TAG_SEND_FM_CUT_BLOCKS = 350;


}
