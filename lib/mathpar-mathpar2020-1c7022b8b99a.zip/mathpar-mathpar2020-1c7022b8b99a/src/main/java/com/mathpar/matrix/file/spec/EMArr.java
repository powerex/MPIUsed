/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.matrix.file.spec;


/**
 * @author Yuri Valeev
 * @version 2.0
 */
public class EMArr {
    public int[] ei;
    public int[] ej;

    public EMArr(int[] ei,int[] ej){
        this.ei=ei;
        this.ej=ej;
    }
}
