/**
* Copyright © 2011 Mathparca Ltd. All rights reserved.
*/

package com.mathpar.parallel.utils.parallel_debugger;

import mpi.*;
/**
 *
 * @author r1d1
 */
public class DebugExample {
    public static void main(String[] args) {
        
    }
}
